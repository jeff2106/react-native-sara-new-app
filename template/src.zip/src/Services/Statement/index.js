export { default as GetDeclarationPending } from './statement_getPending'
export { default as GetDeclarationRejected } from './statement_getRejected'
export { default as GetDeclarationSucceed } from './statement_getSucceed'
