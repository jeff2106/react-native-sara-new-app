/**
 * Images should be stored in the `App/Images` directory and referenced using variables defined here.
 */

export default function () {
  return {
    logo: {
      uri:
        'https://thecodingmachine.github.io/react-native-global_pay/img/TOM-small.png',
    },
  }
}
